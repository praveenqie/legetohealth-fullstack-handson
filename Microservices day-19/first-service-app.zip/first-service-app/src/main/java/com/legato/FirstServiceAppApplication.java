package com.legato;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FirstServiceAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(FirstServiceAppApplication.class, args);
	}

}
