package com.legato.clentserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClentServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClentServerApplication.class, args);
	}

}
